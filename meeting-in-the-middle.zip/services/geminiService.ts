
import { GoogleGenAI, Type } from "@google/genai";
import { ScenarioInput, AnalysisResult, LocationAnalysis, AttendeeTravelDetail } from '../types';
import { CANDIDATE_CITIES } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

const attendeeTravelDetailSchema = {
    type: Type.OBJECT,
    properties: {
        office: { type: Type.STRING },
        travel_hours: { type: Type.NUMBER, description: "Round-trip travel time in hours." },
        co2_kg: { type: Type.NUMBER, description: "Round-trip CO2 emissions in kg for one person." },
        attendee_count: { type: Type.INTEGER, description: "Number of attendees from this office." },
    },
    required: ['office', 'travel_hours', 'co2_kg', 'attendee_count'],
};

const locationAnalysisSchema = {
    type: Type.OBJECT,
    properties: {
        event_location: { type: Type.STRING },
        total_co2_kg: { type: Type.NUMBER },
        average_travel_hours: { type: Type.NUMBER },
        median_travel_hours: { type: Type.NUMBER },
        max_travel_hours: { type: Type.NUMBER },
        min_travel_hours: { type: Type.NUMBER },
        attendee_travel_details: {
            type: Type.ARRAY,
            items: attendeeTravelDetailSchema
        },
        optimality_score: { type: Type.NUMBER },
    },
    required: [
        'event_location', 'total_co2_kg', 'average_travel_hours', 'median_travel_hours',
        'max_travel_hours', 'min_travel_hours', 'attendee_travel_details', 'optimality_score'
    ],
};

const finalResponseSchema = {
    type: Type.OBJECT,
    properties: {
        top_recommendation: locationAnalysisSchema,
        rationale: { type: Type.STRING },
        alternatives: {
            type: Type.ARRAY,
            items: locationAnalysisSchema
        },
    },
    required: ['top_recommendation', 'rationale', 'alternatives'],
};


export const analyzeMeetingLocation = async (scenario: ScenarioInput, weights: { co2: number; fairness: number }): Promise<AnalysisResult> => {
    const candidateCityNames = CANDIDATE_CITIES.map(c => c.name);

    const prompt = `
You are a sophisticated travel logistics and sustainability AI assistant for QRT, a global research firm. Your goal is to find the best meeting location that balances travel fairness (travel time) and environmental impact (CO2 emissions).

**Scenario Details:**
${JSON.stringify(scenario, null, 2)}

**Task:**
Analyze the following potential meeting locations: ${candidateCityNames.join(', ')}.

For each potential location, perform the following steps:
1. For each attending office in the scenario, estimate the realistic round-trip flight duration (in hours, including layovers) and CO2 emissions (in kg per person). Use data for major international airports.
2. For each location, create a detailed breakdown in 'attendee_travel_details'. This must be an array where each object contains the origin 'office', 'travel_hours', 'co2_kg', and the 'attendee_count' from the input scenario.
3. Calculate the total CO2 emissions for ALL attendees traveling to this location (sum of co2_kg * attendee_count for each office).
4. Create a flat list of all individual travel times (e.g., if Mumbai has 2 attendees with 10 travel hours, the list contains [10, 10]). From this list, calculate the following statistics: average, median, maximum, and minimum travel hours.
5. Calculate a 'fairness score' for each location. This score is the standard deviation of all individual attendee travel times. A lower score is better (more fair).
6. Calculate an overall 'optimality score' for each location. First, normalize the 'Total CO2' and 'Fairness Score' across all candidate cities to a 0-1 scale (0 for min value, 1 for max value). Then, apply the following user-defined weights: CO2 Weight = ${weights.co2}, Fairness Weight = ${weights.fairness}. The final score is (normalized_co2 * co2_weight) + (normalized_fairness * fairness_weight). A lower optimality score is better.

**Output:**
Provide your full analysis as a single, valid JSON object that strictly adheres to the provided schema. The output should include:
- The single 'top_recommendation' location (the one with the lowest optimality score).
- A concise 2-3 sentence 'rationale' explaining why the top recommendation is a good balance based on the provided weights and scenario.
- A list of 4 'alternatives', also sorted by their optimality score (lowest to highest).

Do not include any text, markdown formatting, or explanations outside of the final JSON object.
`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: finalResponseSchema,
            },
        });
        
        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText) as AnalysisResult;

        // Basic validation
        if (!result.top_recommendation || !result.alternatives || result.alternatives.length === 0) {
            throw new Error("Invalid data structure received from API.");
        }

        return result;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to get analysis from Gemini. The model may have returned an invalid response. Please try again.");
    }
};
