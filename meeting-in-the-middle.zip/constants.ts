
import { ScenarioInput, City } from './types';

export const DEFAULT_SCENARIO: ScenarioInput = {
  attendees: {
    'Mumbai': 2,
    'Shanghai': 3,
    'Hong Kong': 1,
    'Singapore': 2,
    'Sydney': 2
  },
  availability_window: {
    start: '2025-12-10',
    end: '2025-12-15'
  },
  event_duration: {
    days: 0,
    hours: 4
  }
};

export const OFFICE_LOCATIONS: Record<string, City> = {
    'Mumbai': { name: 'Mumbai', country: 'India', lat: 19.0760, lon: 72.8777 },
    'Shanghai': { name: 'Shanghai', country: 'China', lat: 31.2304, lon: 121.4737 },
    'Hong Kong': { name: 'Hong Kong', country: 'China', lat: 22.3193, lon: 114.1694 },
    'Singapore': { name: 'Singapore', country: 'Singapore', lat: 1.3521, lon: 103.8198 },
    'Sydney': { name: 'Sydney', country: 'Australia', lat: -33.8688, lon: 151.2093 },
    'London': { name: 'London', country: 'UK', lat: 51.5072, lon: -0.1276 },
    'Paris': { name: 'Paris', country: 'France', lat: 48.8566, lon: 2.3522 },
    'New York': { name: 'New York', country: 'USA', lat: 40.7128, lon: -74.0060 },
    'San Francisco': { name: 'San Francisco', country: 'USA', lat: 37.7749, lon: -122.4194 },
    'Dubai': { name: 'Dubai', country: 'UAE', lat: 25.2048, lon: 55.2708 },
    'Tokyo': { name: 'Tokyo', country: 'Japan', lat: 35.6762, lon: 139.6503 },
    'Warsaw': { name: 'Warsaw', country: 'Poland', lat: 52.2297, lon: 21.0122 },
    'Bengaluru': { name: 'Bengaluru', country: 'India', lat: 12.9716, lon: 77.5946 },
};

export const CANDIDATE_CITIES: City[] = [
    ...Object.values(OFFICE_LOCATIONS),
    { name: 'Frankfurt', country: 'Germany', lat: 50.1109, lon: 8.6821 },
    { name: 'Amsterdam', country: 'Netherlands', lat: 52.3676, lon: 4.9041 },
    { name: 'Istanbul', country: 'Turkey', lat: 41.0082, lon: 28.9784 },
    { name: 'Bangkok', country: 'Thailand', lat: 13.7563, lon: 100.5018 },
    { name: 'Chicago', country: 'USA', lat: 41.8781, lon: -87.6298 },
];
