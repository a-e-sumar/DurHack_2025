
import React, { useState, useCallback } from 'react';
import { ScenarioInput, AnalysisResult } from './types';
import { analyzeMeetingLocation } from './services/geminiService';
import { DEFAULT_SCENARIO } from './constants';
import ScenarioForm from './components/ScenarioForm';
import ResultsDisplay from './components/ResultsDisplay';
import { LogoIcon } from './components/Icons';

const App: React.FC = () => {
  const [scenario, setScenario] = useState<ScenarioInput>(DEFAULT_SCENARIO);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = useCallback(async (currentScenario: ScenarioInput, weights: { co2: number; fairness: number }) => {
    setIsLoading(true);
    setError(null);
    setAnalysis(null);
    try {
      const result = await analyzeMeetingLocation(currentScenario, weights);
      setAnalysis(result);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-brand-dark text-gray-200 font-sans">
      <header className="bg-brand-secondary/50 backdrop-blur-sm sticky top-0 z-10 border-b border-gray-700">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <LogoIcon className="h-8 w-8 text-brand-accent" />
            <h1 className="text-xl md:text-2xl font-bold text-white tracking-tight">
              Meeting in the Middle
            </h1>
          </div>
          <p className="hidden md:block text-sm text-gray-400">Optimal Meeting Planner</p>
        </div>
      </header>
      <main className="container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-4 xl:col-span-3">
            <ScenarioForm
              scenario={scenario}
              setScenario={setScenario}
              onAnalyze={handleAnalyze}
              isLoading={isLoading}
            />
          </div>
          <div className="lg:col-span-8 xl:col-span-9">
            <ResultsDisplay
              analysis={analysis}
              isLoading={isLoading}
              error={error}
              scenario={scenario}
            />
          </div>
        </div>
      </main>
      <footer className="text-center py-4 text-gray-500 text-xs border-t border-gray-800 mt-8">
        <p>Powered by Gemini API. Designed for QRT Hackathon.</p>
      </footer>
    </div>
  );
};

export default App;
