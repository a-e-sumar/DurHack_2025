
import React from 'react';
import { LocationAnalysis, ScenarioInput } from '../types';
import { OFFICE_LOCATIONS, CANDIDATE_CITIES } from '../constants';

interface TravelMapProps {
  recommendation: LocationAnalysis;
  scenario: ScenarioInput;
}

// Simple equirectangular projection
const project = (lat: number, lon: number, width: number, height: number) => {
  const x = (lon + 180) * (width / 360);
  const y = (lat * -1 + 90) * (height / 180);
  return { x, y };
};

const TravelMap: React.FC<TravelMapProps> = ({ recommendation, scenario }) => {
  const width = 800;
  const height = 400;
  
  const allCities = { ...OFFICE_LOCATIONS, ...CANDIDATE_CITIES.reduce((acc, city) => ({ ...acc, [city.name]: city }), {}) };
  const destinationCity = allCities[recommendation.event_location];

  if (!destinationCity) return <div>Destination city not found.</div>;

  const destinationCoords = project(destinationCity.lat, destinationCity.lon, width, height);

  const originPoints = Object.keys(scenario.attendees)
    .map(officeName => {
        const officeCity = OFFICE_LOCATIONS[officeName];
        if (!officeCity) return null;
        const startCoords = project(officeCity.lat, officeCity.lon, width, height);
        const numAttendees = scenario.attendees[officeName] || 1;
        return {
            name: officeName,
            start: startCoords,
            attendees: numAttendees,
        };
    })
    .filter(p => p !== null);

  return (
    <div className="relative w-full aspect-[2/1] bg-gray-900 rounded-md overflow-hidden">
      <svg width="100%" height="100%" viewBox={`0 0 ${width} ${height}`}>
        <image href="https://picsum.photos/seed/mapbg/800/400" x="0" y="0" width={width} height={height} opacity="0.1" />
        
        {/* Travel Paths */}
        {originPoints.map(origin => {
          if (!origin) return null;
          const strokeWidth = Math.max(1, Math.min(5, origin.attendees));
          return (
            <g key={origin.name}>
                <path
                    d={`M${origin.start.x},${origin.start.y} Q${(origin.start.x + destinationCoords.x) / 2},${(origin.start.y + destinationCoords.y) / 2 - 50} ${destinationCoords.x},${destinationCoords.y}`}
                    stroke="rgba(66, 153, 225, 0.5)"
                    strokeWidth={strokeWidth}
                    fill="none"
                />
            </g>
          );
        })}
        
        {/* Origin Points */}
        {originPoints.map(origin => {
           if (!origin) return null;
           return (
             <g key={origin.name} className="group cursor-pointer">
                <circle cx={origin.start.x} cy={origin.start.y} r="4" fill="#cbd5e0" />
                <text x={origin.start.x + 6} y={origin.start.y + 4} className="text-[8px] fill-gray-300 hidden group-hover:block transition-all">{origin.name}</text>
             </g>
           )
        })}
        
        {/* Destination Point */}
        <g className="group cursor-pointer">
          <circle cx={destinationCoords.x} cy={destinationCoords.y} r="8" fill="#4299e1" stroke="#f7fafc" strokeWidth="2" />
          <circle cx={destinationCoords.x} cy={destinationCoords.y} r="8" fill="transparent">
             <animate attributeName="r" from="6" to="16" dur="1.5s" begin="0s" repeatCount="indefinite"/>
             <animate attributeName="opacity" from="1" to="0" dur="1.5s" begin="0s" repeatCount="indefinite"/>
          </circle>
          <text x={destinationCoords.x + 10} y={destinationCoords.y + 5} className="text-[10px] font-bold fill-white">{recommendation.event_location}</text>
        </g>
      </svg>
    </div>
  );
};

export default TravelMap;
