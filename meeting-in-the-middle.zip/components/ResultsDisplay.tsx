
import React from 'react';
import { AnalysisResult, ScenarioInput } from '../types';
import { Card } from './Card';
import TravelMap from './TravelMap';
import ComparisonChart from './ComparisonChart';
import { RationaleIcon, StatsIcon, AlternativesIcon, GlobeIcon } from './Icons';

interface ResultsDisplayProps {
  analysis: AnalysisResult | null;
  isLoading: boolean;
  error: string | null;
  scenario: ScenarioInput;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ analysis, isLoading, error, scenario }) => {
  if (isLoading) {
    return (
      <Card>
        <div className="p-6 h-96 flex flex-col items-center justify-center text-center">
          <svg className="animate-spin h-12 w-12 text-brand-accent mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <h3 className="text-xl font-semibold text-white">Analyzing Scenarios...</h3>
          <p className="text-gray-400 mt-2">Gemini is crunching the numbers to find the optimal meeting location. This may take a moment.</p>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <div className="p-6 h-96 flex flex-col items-center justify-center text-center bg-red-900/20">
          <h3 className="text-xl font-semibold text-red-400">Analysis Failed</h3>
          <p className="text-gray-300 mt-2">{error}</p>
        </div>
      </Card>
    );
  }

  if (!analysis) {
    return (
      <Card>
        <div className="p-6 h-96 flex flex-col items-center justify-center text-center">
          <GlobeIcon className="h-16 w-16 text-gray-600 mb-4" />
          <h3 className="text-xl font-semibold text-white">Ready for Analysis</h3>
          <p className="text-gray-400 mt-2">Configure your scenario on the left and click "Analyze" to find the best meeting location.</p>
        </div>
      </Card>
    );
  }
  
  const { top_recommendation, rationale, alternatives } = analysis;
  const allLocations = [top_recommendation, ...alternatives];

  return (
    <div className="space-y-8">
      {/* Top Recommendation */}
      <Card>
        <div className="p-6">
          <span className="text-sm font-semibold text-brand-accent uppercase tracking-wider">Top Recommendation</span>
          <h2 className="text-4xl font-bold text-white mt-1">{top_recommendation.event_location}</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-gray-700">
           <div className="bg-brand-secondary p-6">
               <h3 className="font-semibold text-lg flex items-center mb-3"><RationaleIcon className="h-5 w-5 mr-2 text-brand-accent"/>AI Rationale</h3>
               <p className="text-gray-300 text-sm">{rationale}</p>
           </div>
           <div className="bg-brand-secondary p-6">
               <h3 className="font-semibold text-lg flex items-center mb-3"><StatsIcon className="h-5 w-5 mr-2 text-brand-accent"/>Key Metrics</h3>
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                    <div><span className="text-gray-400">Total CO₂:</span> <span className="font-bold text-white">{top_recommendation.total_co2_kg.toLocaleString()} kg</span></div>
                    <div><span className="text-gray-400">Median Travel:</span> <span className="font-bold text-white">{top_recommendation.median_travel_hours.toFixed(1)} hrs</span></div>
                    <div><span className="text-gray-400">Avg Travel:</span> <span className="font-bold text-white">{top_recommendation.average_travel_hours.toFixed(1)} hrs</span></div>
                    <div><span className="text-gray-400">Max Travel:</span> <span className="font-bold text-white">{top_recommendation.max_travel_hours.toFixed(1)} hrs</span></div>
                </div>
           </div>
        </div>
      </Card>

      {/* Map Visualization */}
      <Card>
        <div className="p-6">
            <h3 className="font-semibold text-lg flex items-center"><GlobeIcon className="h-5 w-5 mr-2 text-brand-accent"/>Travel Visualization</h3>
            <p className="text-sm text-gray-400 mb-4">Routes from origin offices to {top_recommendation.event_location}. Line thickness represents the number of attendees.</p>
        </div>
        <div className="bg-gray-800 rounded-b-lg p-2">
            <TravelMap recommendation={top_recommendation} scenario={scenario} />
        </div>
      </Card>

      {/* Alternatives */}
      <Card>
        <div className="p-6">
          <h3 className="font-semibold text-lg flex items-center"><AlternativesIcon className="h-5 w-5 mr-2 text-brand-accent"/>Candidate Comparison</h3>
          <p className="text-sm text-gray-400 mb-4">Comparison of the top 5 potential meeting locations based on total CO₂ and median travel time.</p>
        </div>
        <div className="p-6 pt-0">
          <ComparisonChart data={allLocations} />
        </div>
      </Card>
    </div>
  );
};

export default ResultsDisplay;
