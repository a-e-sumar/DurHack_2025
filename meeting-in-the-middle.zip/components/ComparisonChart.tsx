
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { LocationAnalysis } from '../types';

interface ComparisonChartProps {
  data: LocationAnalysis[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-brand-secondary p-3 border border-gray-600 rounded-md shadow-lg">
        <p className="label font-bold text-white">{`${label}`}</p>
        <p className="text-sm text-sky-300">{`Total CO₂: ${payload[0].value.toLocaleString()} kg`}</p>
        <p className="text-sm text-amber-300">{`Median Travel: ${payload[1].value} hrs`}</p>
      </div>
    );
  }
  return null;
};

const ComparisonChart: React.FC<ComparisonChartProps> = ({ data }) => {
  const chartData = data.map(item => ({
    name: item.event_location,
    'Total CO₂ (kg)': item.total_co2_kg,
    'Median Travel (hrs)': item.median_travel_hours,
  }));

  return (
    <div style={{ width: '100%', height: 300 }}>
      <ResponsiveContainer>
        <BarChart
          data={chartData}
          margin={{
            top: 5, right: 20, left: 20, bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#4a5568" />
          <XAxis dataKey="name" stroke="#a0aec0" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis yAxisId="left" orientation="left" stroke="#a0aec0" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis yAxisId="right" orientation="right" stroke="#a0aec0" fontSize={12} tickLine={false} axisLine={false} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }} />
          <Legend wrapperStyle={{fontSize: "12px"}} />
          <Bar yAxisId="left" dataKey="Total CO₂ (kg)" fill="#4299e1" />
          <Bar yAxisId="right" dataKey="Median Travel (hrs)" fill="#f6ad55" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ComparisonChart;
