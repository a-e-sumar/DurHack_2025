import React, { useState, useRef } from 'react';
import { ScenarioInput } from '../types';
import { OFFICE_LOCATIONS } from '../constants';
import { Card } from './Card';
import { PlusIcon, MinusIcon, UploadIcon, AnalyzeIcon } from './Icons';

interface ScenarioFormProps {
  scenario: ScenarioInput;
  setScenario: React.Dispatch<React.SetStateAction<ScenarioInput>>;
  onAnalyze: (scenario: ScenarioInput, weights: { co2: number; fairness: number }) => void;
  isLoading: boolean;
}

const ScenarioForm: React.FC<ScenarioFormProps> = ({ scenario, setScenario, onAnalyze, isLoading }) => {
  const [weights, setWeights] = useState({ co2: 0.5, fairness: 0.5 });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAttendeeChange = (office: string, count: number) => {
    const newAttendees = { ...scenario.attendees };
    if (count > 0) {
      newAttendees[office] = count;
    } else {
      delete newAttendees[office];
    }
    setScenario({ ...scenario, attendees: newAttendees });
  };
  
  const handleAddAttendee = () => {
    const unselectedOffice = Object.keys(OFFICE_LOCATIONS).find(o => !scenario.attendees[o]);
    if (unselectedOffice) {
        handleAttendeeChange(unselectedOffice, 1);
    }
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setScenario({
      ...scenario,
      availability_window: { ...scenario.availability_window, [e.target.name]: e.target.value }
    });
  };

  const handleDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setScenario({
        ...scenario,
        event_duration: { ...scenario.event_duration, [e.target.name]: parseInt(e.target.value) || 0 }
    });
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const json = JSON.parse(event.target?.result as string);
          // Basic validation
          if (json.attendees && json.availability_window && json.event_duration) {
            setScenario(json);
          } else {
            alert('Invalid JSON format.');
          }
        } catch (error) {
          alert('Error parsing JSON file.');
        }
      };
      reader.readAsText(file);
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card>
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">Scenario</h2>
          <button onClick={triggerFileUpload} className="flex items-center space-x-2 text-sm text-brand-accent hover:text-white transition-colors">
            <UploadIcon className="h-4 w-4" />
            <span>Load JSON</span>
          </button>
          <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".json" className="hidden" />
        </div>

        {/* Attendees */}
        <div>
          <h3 className="font-semibold mb-2">Attendees</h3>
          <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
            {Object.entries(scenario.attendees).map(([office, count]) => (
              <div key={office} className="flex items-center justify-between bg-gray-700/50 p-2 rounded-md">
                <span className="text-sm">{office}</span>
                <div className="flex items-center space-x-2">
                  {/* FIX: Explicitly convert `count` to a number to prevent type errors. */}
                  <button onClick={() => handleAttendeeChange(office, Number(count) - 1)} className="p-1 rounded-full bg-gray-600 hover:bg-red-500 transition-colors"><MinusIcon className="h-3 w-3" /></button>
                  <span className="w-6 text-center text-sm font-medium">{Number(count)}</span>
                  {/* FIX: Explicitly convert `count` to a number to prevent type errors. */}
                  <button onClick={() => handleAttendeeChange(office, Number(count) + 1)} className="p-1 rounded-full bg-gray-600 hover:bg-green-500 transition-colors"><PlusIcon className="h-3 w-3" /></button>
                </div>
              </div>
            ))}
          </div>
          <button onClick={handleAddAttendee} className="mt-2 w-full flex items-center justify-center space-x-2 text-sm py-1.5 bg-gray-700 hover:bg-brand-accent transition-colors rounded-md">
             <PlusIcon className="h-4 w-4" />
             <span>Add Office</span>
          </button>
        </div>

        {/* Availability */}
        <div>
          <h3 className="font-semibold mb-2">Availability Window</h3>
          <div className="grid grid-cols-2 gap-2">
            <input type="date" name="start" value={scenario.availability_window.start} onChange={handleDateChange} className="bg-gray-700/50 p-2 rounded-md text-sm w-full outline-none focus:ring-2 focus:ring-brand-accent" />
            <input type="date" name="end" value={scenario.availability_window.end} onChange={handleDateChange} className="bg-gray-700/50 p-2 rounded-md text-sm w-full outline-none focus:ring-2 focus:ring-brand-accent" />
          </div>
        </div>
        
        {/* Duration */}
        <div>
           <h3 className="font-semibold mb-2">Event Duration</h3>
           <div className="flex items-center space-x-2">
                <input type="number" name="days" value={scenario.event_duration.days} onChange={handleDurationChange} className="bg-gray-700/50 p-2 rounded-md text-sm w-full outline-none focus:ring-2 focus:ring-brand-accent" />
                <span className="text-sm text-gray-400">days</span>
                <input type="number" name="hours" value={scenario.event_duration.hours} onChange={handleDurationChange} className="bg-gray-700/50 p-2 rounded-md text-sm w-full outline-none focus:ring-2 focus:ring-brand-accent" />
                <span className="text-sm text-gray-400">hours</span>
           </div>
        </div>
        
        {/* Weights */}
        <div>
          <h3 className="font-semibold mb-2">Priorities</h3>
          <div className="space-y-3">
             <div>
                <div className="flex justify-between text-sm mb-1">
                    <span>CO₂ Emissions</span>
                    <span className="font-bold">{Math.round(weights.co2 * 100)}%</span>
                </div>
                <input type="range" min="0" max="1" step="0.05" value={weights.co2} onChange={(e) => setWeights({ co2: parseFloat(e.target.value), fairness: 1 - parseFloat(e.target.value) })} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-brand-accent" />
             </div>
             <div>
                <div className="flex justify-between text-sm mb-1">
                    <span>Travel Fairness</span>
                    <span className="font-bold">{Math.round(weights.fairness * 100)}%</span>
                </div>
                 <input type="range" min="0" max="1" step="0.05" value={weights.fairness} onChange={(e) => setWeights({ fairness: parseFloat(e.target.value), co2: 1 - parseFloat(e.target.value) })} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-brand-accent" />
             </div>
          </div>
        </div>

        <button onClick={() => onAnalyze(scenario, weights)} disabled={isLoading} className="w-full bg-brand-accent hover:bg-blue-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center transition-all duration-300">
          {isLoading ? (
            <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : (
            <>
                <AnalyzeIcon className="h-5 w-5 mr-2"/>
                <span>Analyze Optimal Location</span>
            </>
          )}
        </button>
      </div>
    </Card>
  );
};

export default ScenarioForm;