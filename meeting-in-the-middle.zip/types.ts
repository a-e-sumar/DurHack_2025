
export interface ScenarioInput {
  attendees: Record<string, number>;
  availability_window: {
    start: string;
    end: string;
  };
  event_duration: {
    days: number;
    hours: number;
  };
}

export interface AttendeeTravelDetail {
    office: string;
    travel_hours: number;
    co2_kg: number;
    attendee_count: number;
}

export interface LocationAnalysis {
  event_location: string;
  total_co2_kg: number;
  average_travel_hours: number;
  median_travel_hours: number;
  max_travel_hours: number;
  min_travel_hours: number;
  attendee_travel_details: AttendeeTravelDetail[];
  optimality_score: number;
}

export interface AnalysisResult {
  top_recommendation: LocationAnalysis;
  rationale: string;
  alternatives: LocationAnalysis[];
}

export interface City {
    name: string;
    country: string;
    lat: number;
    lon: number;
}
